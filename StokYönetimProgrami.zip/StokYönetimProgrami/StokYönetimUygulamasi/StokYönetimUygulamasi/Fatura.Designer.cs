﻿namespace StokYönetimUygulamasi
{
    partial class Fatura
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Fatura));
            BıllIdTb = new TextBox();
            FProductTb = new TextBox();
            FPriceTb = new TextBox();
            QtyTb = new TextBox();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            button1 = new Button();
            FMobileGv = new DataGridView();
            FAccessorieGv = new DataGridView();
            BıllGv = new DataGridView();
            Column1 = new DataGridViewTextBoxColumn();
            Column2 = new DataGridViewTextBoxColumn();
            Column3 = new DataGridViewTextBoxColumn();
            Column4 = new DataGridViewTextBoxColumn();
            Column5 = new DataGridViewTextBoxColumn();
            button2 = new Button();
            printDocument1 = new System.Drawing.Printing.PrintDocument();
            printPreviewDialog1 = new PrintPreviewDialog();
            label5 = new Label();
            Grdtotallbl = new Label();
            button5 = new Button();
            FtotalLbl = new Label();
            pageSetupDialog1 = new PageSetupDialog();
            printDialog1 = new PrintDialog();
            button3 = new Button();
            button4 = new Button();
            button6 = new Button();
            ((System.ComponentModel.ISupportInitialize)FMobileGv).BeginInit();
            ((System.ComponentModel.ISupportInitialize)FAccessorieGv).BeginInit();
            ((System.ComponentModel.ISupportInitialize)BıllGv).BeginInit();
            SuspendLayout();
            // 
            // BıllIdTb
            // 
            BıllIdTb.Location = new Point(154, 73);
            BıllIdTb.Name = "BıllIdTb";
            BıllIdTb.Size = new Size(154, 23);
            BıllIdTb.TabIndex = 0;
            BıllIdTb.TextChanged += textBox1_TextChanged;
            // 
            // FProductTb
            // 
            FProductTb.Location = new Point(154, 116);
            FProductTb.Name = "FProductTb";
            FProductTb.Size = new Size(154, 23);
            FProductTb.TabIndex = 1;
            FProductTb.TextChanged += textBox2_TextChanged;
            // 
            // FPriceTb
            // 
            FPriceTb.Location = new Point(154, 165);
            FPriceTb.Name = "FPriceTb";
            FPriceTb.Size = new Size(154, 23);
            FPriceTb.TabIndex = 2;
            // 
            // QtyTb
            // 
            QtyTb.Location = new Point(154, 215);
            QtyTb.Name = "QtyTb";
            QtyTb.Size = new Size(154, 23);
            QtyTb.TabIndex = 3;
            QtyTb.TextChanged += textBox4_TextChanged;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Arial", 15.75F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(33, 73);
            label1.Name = "label1";
            label1.Size = new Size(115, 24);
            label1.TabIndex = 4;
            label1.Text = "Fatura No:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Arial", 15.75F, FontStyle.Bold, GraphicsUnit.Point);
            label2.Location = new Point(65, 116);
            label2.Name = "label2";
            label2.Size = new Size(83, 24);
            label2.TabIndex = 5;
            label2.Text = "Ürün :  ";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Arial", 15.75F, FontStyle.Bold, GraphicsUnit.Point);
            label3.Location = new Point(65, 215);
            label3.Name = "label3";
            label3.Size = new Size(76, 24);
            label3.TabIndex = 6;
            label3.Text = "Adet : ";
            label3.Click += label3_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Arial", 15.75F, FontStyle.Bold, GraphicsUnit.Point);
            label4.Location = new Point(65, 165);
            label4.Name = "label4";
            label4.Size = new Size(82, 24);
            label4.TabIndex = 7;
            label4.Text = "Fiyatı : ";
            // 
            // button1
            // 
            button1.Font = new Font("Arial", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            button1.Location = new Point(21, 270);
            button1.Name = "button1";
            button1.Size = new Size(183, 41);
            button1.TabIndex = 8;
            button1.Text = "Faturaya Ekle";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // FMobileGv
            // 
            FMobileGv.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            FMobileGv.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            FMobileGv.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            FMobileGv.Location = new Point(465, 73);
            FMobileGv.Name = "FMobileGv";
            FMobileGv.ReadOnly = true;
            FMobileGv.RowTemplate.Height = 25;
            FMobileGv.Size = new Size(852, 343);
            FMobileGv.TabIndex = 9;
            FMobileGv.CellContentClick += FMobileGv_CellContentClick;
            // 
            // FAccessorieGv
            // 
            FAccessorieGv.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            FAccessorieGv.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            FAccessorieGv.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            FAccessorieGv.Location = new Point(465, 455);
            FAccessorieGv.Name = "FAccessorieGv";
            FAccessorieGv.ReadOnly = true;
            FAccessorieGv.RowTemplate.Height = 25;
            FAccessorieGv.Size = new Size(852, 364);
            FAccessorieGv.TabIndex = 10;
            FAccessorieGv.CellContentClick += FAccessorieGv_CellContentClick;
            // 
            // BıllGv
            // 
            BıllGv.Anchor = AnchorStyles.Left;
            BıllGv.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            BıllGv.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            BıllGv.Columns.AddRange(new DataGridViewColumn[] { Column1, Column2, Column3, Column4, Column5 });
            BıllGv.Location = new Point(12, 336);
            BıllGv.Name = "BıllGv";
            BıllGv.RowTemplate.Height = 25;
            BıllGv.Size = new Size(431, 381);
            BıllGv.TabIndex = 11;
            BıllGv.CellContentClick += BıllGv_CellContentClick;
            // 
            // Column1
            // 
            Column1.HeaderText = "No";
            Column1.Name = "Column1";
            // 
            // Column2
            // 
            Column2.HeaderText = "Ürün";
            Column2.Name = "Column2";
            // 
            // Column3
            // 
            Column3.HeaderText = "Fiyat";
            Column3.Name = "Column3";
            // 
            // Column4
            // 
            Column4.HeaderText = "Adet";
            Column4.Name = "Column4";
            // 
            // Column5
            // 
            Column5.HeaderText = "Toplam";
            Column5.Name = "Column5";
            // 
            // button2
            // 
            button2.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            button2.Font = new Font("Arial", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            button2.Location = new Point(12, 783);
            button2.Name = "button2";
            button2.Size = new Size(136, 36);
            button2.TabIndex = 12;
            button2.Text = "Fatura Oluştur";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // printDocument1
            // 
            printDocument1.PrintPage += printDocument1_PrintPage;
            // 
            // printPreviewDialog1
            // 
            printPreviewDialog1.AutoScrollMargin = new Size(0, 0);
            printPreviewDialog1.AutoScrollMinSize = new Size(0, 0);
            printPreviewDialog1.ClientSize = new Size(400, 300);
            printPreviewDialog1.Document = printDocument1;
            printPreviewDialog1.Enabled = true;
            printPreviewDialog1.Icon = (Icon)resources.GetObject("printPreviewDialog1.Icon");
            printPreviewDialog1.Name = "printPreviewDialog1";
            printPreviewDialog1.Visible = false;
            // 
            // label5
            // 
            label5.Anchor = AnchorStyles.Left;
            label5.AutoSize = true;
            label5.Font = new Font("Arial", 18F, FontStyle.Bold, GraphicsUnit.Point);
            label5.Location = new Point(12, 733);
            label5.Name = "label5";
            label5.Size = new Size(92, 29);
            label5.TabIndex = 13;
            label5.Text = "Tutar : ";
            label5.Click += label5_Click;
            // 
            // Grdtotallbl
            // 
            Grdtotallbl.Anchor = AnchorStyles.Left;
            Grdtotallbl.AutoSize = true;
            Grdtotallbl.Font = new Font("Arial", 15.75F, FontStyle.Bold, GraphicsUnit.Point);
            Grdtotallbl.Location = new Point(108, 733);
            Grdtotallbl.Name = "Grdtotallbl";
            Grdtotallbl.Size = new Size(0, 24);
            Grdtotallbl.TabIndex = 14;
            Grdtotallbl.Click += label6_Click;
            // 
            // button5
            // 
            button5.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            button5.AutoSize = true;
            button5.Font = new Font("Arial", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            button5.Location = new Point(1228, 12);
            button5.Margin = new Padding(4, 3, 4, 3);
            button5.Name = "button5";
            button5.Size = new Size(88, 32);
            button5.TabIndex = 31;
            button5.Text = "Menü";
            button5.UseVisualStyleBackColor = true;
            button5.Click += button5_Click;
            // 
            // FtotalLbl
            // 
            FtotalLbl.Anchor = AnchorStyles.Left;
            FtotalLbl.AutoSize = true;
            FtotalLbl.Font = new Font("Arial", 15.75F, FontStyle.Bold, GraphicsUnit.Point);
            FtotalLbl.Location = new Point(94, 738);
            FtotalLbl.Name = "FtotalLbl";
            FtotalLbl.Size = new Size(54, 24);
            FtotalLbl.TabIndex = 32;
            FtotalLbl.Text = "0 TL";
            FtotalLbl.Click += FtotalLbl_Click;
            // 
            // pageSetupDialog1
            // 
            pageSetupDialog1.Document = printDocument1;
            // 
            // printDialog1
            // 
            printDialog1.UseEXDialog = true;
            // 
            // button3
            // 
            button3.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            button3.Font = new Font("Arial", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            button3.Location = new Point(154, 783);
            button3.Name = "button3";
            button3.Size = new Size(142, 36);
            button3.TabIndex = 33;
            button3.Text = "Ayarla";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // button4
            // 
            button4.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            button4.Font = new Font("Arial", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            button4.Location = new Point(301, 783);
            button4.Name = "button4";
            button4.Size = new Size(142, 36);
            button4.TabIndex = 34;
            button4.Text = "Önizle";
            button4.UseVisualStyleBackColor = true;
            button4.Click += button4_Click;
            // 
            // button6
            // 
            button6.Font = new Font("Arial", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            button6.Location = new Point(232, 270);
            button6.Name = "button6";
            button6.Size = new Size(183, 41);
            button6.TabIndex = 35;
            button6.Text = "Faturadan Sil";
            button6.UseVisualStyleBackColor = true;
            button6.Click += button6_Click;
            // 
            // Fatura
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.DimGray;
            ClientSize = new Size(1329, 845);
            Controls.Add(button6);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(FtotalLbl);
            Controls.Add(button5);
            Controls.Add(Grdtotallbl);
            Controls.Add(label5);
            Controls.Add(button2);
            Controls.Add(BıllGv);
            Controls.Add(FAccessorieGv);
            Controls.Add(FMobileGv);
            Controls.Add(button1);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(QtyTb);
            Controls.Add(FPriceTb);
            Controls.Add(FProductTb);
            Controls.Add(BıllIdTb);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "Fatura";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Fatura";
            Load += Fatura_Load;
            ((System.ComponentModel.ISupportInitialize)FMobileGv).EndInit();
            ((System.ComponentModel.ISupportInitialize)FAccessorieGv).EndInit();
            ((System.ComponentModel.ISupportInitialize)BıllGv).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox BıllIdTb;
        private TextBox FProductTb;
        private TextBox FPriceTb;
        private TextBox QtyTb;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Button button1;
        private DataGridView FMobileGv;
        private DataGridView FAccessorieGv;
        private DataGridView BıllGv;
        private DataGridViewTextBoxColumn Column1;
        private DataGridViewTextBoxColumn Column2;
        private DataGridViewTextBoxColumn Column3;
        private DataGridViewTextBoxColumn Column4;
        private DataGridViewTextBoxColumn Column5;
        private Button button2;
        private System.Drawing.Printing.PrintDocument printDocument1;
        private PrintPreviewDialog printPreviewDialog1;
        private Label label5;
        private Label Grdtotallbl;
        private Label Grdtotal;
        private Button button5;
        private Label FtotalLbl;
        private PageSetupDialog pageSetupDialog1;
        private PrintDialog printDialog1;
        private Button button3;
        private Button button4;
        private Button button6;
    }
}