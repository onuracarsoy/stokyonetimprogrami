﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data.SqlTypes;

namespace StokYönetimUygulamasi
{
    public partial class Telefon : Form
    {
        public Telefon()
        {
            InitializeComponent();
        }
        SqlConnection Con = new SqlConnection(@"Data Source=WINDEV2209EVAL;Initial Catalog=StokYonetim;Integrated Security=True");

        private void populate()
        {
            Con.Open();
            String query = "Select * from MobileTbl";
            SqlDataAdapter da = new SqlDataAdapter(query, Con);
            SqlCommandBuilder builder = new SqlCommandBuilder(da);
            var ds = new DataSet();
            da.Fill(ds);
            MobileGv.DataSource = ds.Tables[0];
            Con.Close();
        }
        private void textBox3_TextChanged(object sender, EventArgs e)
        {
        }

        private void Mobile_Load(object sender, EventArgs e)
        {
            populate();

        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (IdTb.Text == "" || BrandTb.Text == "" || ModeleTb.Text == "" || PriceTb.Text == "" || StockTb.Text == "")
            {
                MessageBox.Show("Lütfen Tümünü Doldurunuz!");
            }
            else
            {
                try
                {
                    Con.Open();
                    String sql = "insert into MobileTbl values(" + IdTb.Text + ",'" + BrandTb.Text + "','" + ModeleTb.Text + "','" + PriceTb.Text + "','" + StockTb.Text + "','" + RamCb.SelectedItem.ToString() + "','" + MemoryCb.SelectedItem.ToString() + "')";
                    SqlCommand cmd = new SqlCommand(sql, Con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Başarı ile eklendi!");
                    Con.Close();
                    populate();

                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }

            }
        }

        private void IdTb_TextChanged(object sender, EventArgs e)
        {

        }

        private void RamGb_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void MobileGv_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
           

            IdTb.Text = MobileGv.CurrentRow.Cells[0].Value.ToString();
            BrandTb.Text = MobileGv.CurrentRow.Cells[1].Value.ToString();
            ModeleTb.Text = MobileGv.CurrentRow.Cells[2].Value.ToString();
            PriceTb.Text = MobileGv.CurrentRow.Cells[3].Value.ToString();
            StockTb.Text = MobileGv.CurrentRow.Cells[4].Value.ToString();
            RamCb.SelectedItem = MobileGv.CurrentRow.Cells[5].Value.ToString();
            MemoryCb.SelectedItem = MobileGv.CurrentRow.Cells[6].Value.ToString();


        }

        private void button4_Click(object sender, EventArgs e)
        {
            IdTb.Text = "";
            BrandTb.Text = "";
            ModeleTb.Text = "";
            PriceTb.Text = "";
            StockTb.Text = "";
        }

        private void button3_Click(object sender, EventArgs e)
        {


            if (IdTb.Text == "")
            {
                MessageBox.Show("Lütfen Id Bilgisi Giriniz!");
            }

            else
            {
                try
                {
                    Con.Open();
                    string query = "delete from MobileTbl where MobileId=" + IdTb.Text + "";
                    SqlCommand cmd = new SqlCommand(query, Con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Başarı ile silindi!");
                    Con.Close();
                    populate();

                }
                catch (Exception Ex)
                {

                }
            }
        }

        private void button2_Click(object sender, EventArgs e)

        {

            if (IdTb.Text == "" || BrandTb.Text == "" || ModeleTb.Text == "" || PriceTb.Text == "" || StockTb.Text == "")
            {
                MessageBox.Show("Lütfen Tümünü Doldurunuz!");
            }

            else
            {
                try
                {
                    Con.Open();
                    String sql = "update MobileTbl set MobileBrand='" + BrandTb.Text + "', MobileModel='" + ModeleTb.Text + "', MobilePrice='" + PriceTb.Text + "', MobileStock='" + StockTb.Text + "', MobileRam=" + RamCb.SelectedItem.ToString() + ", MobileMemory=" + MemoryCb.SelectedItem.ToString() + " where MobileId=" + IdTb.Text + ";";
                    SqlCommand cmd = new SqlCommand(sql, Con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Başarı ile güncellendi!");
                    Con.Close();
                    populate();

                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }

            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Menu mn = new Menu();
            mn.Show();
            this.Hide();
        }
    }
}
