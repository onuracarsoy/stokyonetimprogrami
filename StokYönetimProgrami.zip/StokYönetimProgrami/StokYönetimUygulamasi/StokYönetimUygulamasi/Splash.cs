namespace StokYönetimUygulamasi
{
    public partial class Splash : Form
    {
        public Splash()
        {
            InitializeComponent();
        }

        int startpoint = 10; //açılması gereken sürenin değişkeni
        private void label1_Click(object sender, EventArgs e)
        {


        }


        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            startpoint += 3;
            progressBar2.Value = startpoint;

            if (progressBar2.Value == 100)
            {
                progressBar2.Value = 0;
                timer1.Stop();
                Giris log = new Giris();
                log.Show();
                this.Hide();
            }

        }

        private void Splash_Load(object sender, EventArgs e)
        {
            timer1.Start(); ;

        }

        private void progressBar2_Click(object sender, EventArgs e)
        {

        }
    }
}
