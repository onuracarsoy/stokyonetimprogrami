﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StokYönetimUygulamasi
{
    public partial class Menu : Form
    {
        public Menu()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Telefon tel = new Telefon();
            tel.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Aksesuarlar aks = new Aksesuarlar();
            aks.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Fatura ftr = new Fatura();
            ftr.Show();
            this.Hide();
        }

        private void Menu_Load(object sender, EventArgs e)
        {

        }
    }
}
