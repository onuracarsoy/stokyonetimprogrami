﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace StokYönetimUygulamasi
{
    public partial class Fatura : Form
    {
        public Fatura()
        {
            InitializeComponent();
        }

        SqlConnection Con = new SqlConnection(@"Data Source=WINDEV2209EVAL;Initial Catalog=StokYonetim;Integrated Security=True");

        private void Mpopulate()
        {
            Con.Open();
            String query = "Select * from MobileTbl";
            SqlDataAdapter da = new SqlDataAdapter(query, Con);
            SqlCommandBuilder builder = new SqlCommandBuilder(da);
            var ds = new DataSet();
            da.Fill(ds);
            FMobileGv.DataSource = ds.Tables[0];
            Con.Close();
        }
        private void Apopulate()
        {
            Con.Open();
            String query = "Select * from AccessorieTbl";
            SqlDataAdapter da = new SqlDataAdapter(query, Con);
            SqlCommandBuilder builder = new SqlCommandBuilder(da);
            var ds = new DataSet();
            da.Fill(ds);
            FAccessorieGv.DataSource = ds.Tables[0];
            Con.Close();
        }
        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void Fatura_Load(object sender, EventArgs e)
        {
            Mpopulate();
            Apopulate();
        }
        int n = 0, Grdtotall = 0, total;
        private void button1_Click(object sender, EventArgs e)
        {






            if (QtyTb.Text == "" || FPriceTb.Text == "")
            {
                MessageBox.Show("Lütfen Tümünü Doldurun!");
            }
            else
            {
                total = (int)((int)decimal.Parse(QtyTb.Text) * decimal.Parse(FPriceTb.Text));
                DataGridViewRow newRow = new DataGridViewRow();
                newRow.CreateCells(BıllGv);
                newRow.Cells[0].Value = n + 1;
                newRow.Cells[1].Value = FProductTb.Text;
                newRow.Cells[2].Value = FPriceTb.Text;
                newRow.Cells[3].Value = QtyTb.Text;
                newRow.Cells[4].Value = total;
                BıllGv.Rows.Add(newRow);
                n++;
                Grdtotall = Grdtotall + total;
                FtotalLbl.Text = Grdtotall + " TL";





            }

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
        int prodid, prodqty, prodprice, tottal, pos;
        string prodname;
        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            //çizgi çizmek için fırçamı ve kalem nesnemi oluşturdum
            Font myFont = new Font("Calibri", 28);
            SolidBrush sbrush = new SolidBrush(Color.Black);
            Pen myPen = new Pen(Color.Black);

            //Bu kısımda sipariş formu yazısını ve çizgileri yazdırıyorum
            e.Graphics.DrawLine(myPen, 120, 120, 750, 120);
            e.Graphics.DrawLine(myPen, 120, 180, 750, 180);
            e.Graphics.DrawString("FATURA", myFont, sbrush, 350, 120);

            e.Graphics.DrawLine(myPen, 120, 320, 750, 320);

            myFont = new Font("Calibri", 12, FontStyle.Bold);
            e.Graphics.DrawString("Id", myFont, sbrush, 140, 328);
            e.Graphics.DrawString("Ürün Adı", myFont, sbrush, 240, 328);
            e.Graphics.DrawString("Birim Fiyatı", myFont, sbrush, 440, 328);
            e.Graphics.DrawString("Adet", myFont, sbrush, 640, 328);


            e.Graphics.DrawLine(myPen, 120, 348, 750, 348);

            int y = 350;

            StringFormat myStringFormat = new StringFormat();
            myStringFormat.Alignment = StringAlignment.Far;

           

            foreach (DataGridViewRow row in BıllGv.Rows)
            {
                prodid = Convert.ToInt32(row.Cells["Column1"].Value);
                prodname = "" + row.Cells["Column2"].Value;
                prodprice = Convert.ToInt32(row.Cells["Column3"].Value);
                prodqty = Convert.ToInt32(row.Cells["Column4"].Value);
                tottal = Convert.ToInt32(row.Cells["Column5"].Value);
                e.Graphics.DrawString("" + prodid, myFont, sbrush, 155, y, myStringFormat);
                e.Graphics.DrawString("" + prodname, myFont, sbrush, 220, y);
                e.Graphics.DrawString("" + prodprice + " TL", myFont, sbrush, 510, y, myStringFormat);
                e.Graphics.DrawString("" + prodqty, myFont, sbrush, 665, y, myStringFormat);
               
                y += 20;
            }

            e.Graphics.DrawLine(myPen, 120, y, 750, y);
            e.Graphics.DrawString("Toplam: " + Grdtotall + " TL", myFont, sbrush, 700, y + 50, myStringFormat);
            //logo için
            e.Graphics.DrawImage(Properties.Resources.logom, 15, 5);
            //faturano
            e.Graphics.DrawString("Fatura No: " + bıllno, myFont, sbrush, 780, 20, myStringFormat);

           
        }
        int bıllno;
        private void button2_Click(object sender, EventArgs e)
        {
            Random rnd = new Random();
            bıllno = rnd.Next(100000, 9999999);
            BıllIdTb.Text = Convert.ToString(bıllno);



            DialogResult pdr = printDialog1.ShowDialog();
            if (pdr == DialogResult.OK)
            {
                printDocument1.Print();
            }







          
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            Menu mn = new Menu();
            mn.Show();
            this.Hide();
        }

        private void FtotalLbl_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {

            pageSetupDialog1.ShowDialog();

        }

        private void button4_Click(object sender, EventArgs e)
        {
            printPreviewDialog1.ShowDialog();
        }

        private void FMobileGv_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            FProductTb.Text = FMobileGv.CurrentRow.Cells[1].Value.ToString() + " " + FMobileGv.CurrentRow.Cells[2].Value.ToString();

            FPriceTb.Text = FMobileGv.CurrentRow.Cells[3].Value.ToString();



        }

        private void FAccessorieGv_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            FProductTb.Text = FAccessorieGv.CurrentRow.Cells[1].Value.ToString() + " " + FAccessorieGv.CurrentRow.Cells[2].Value.ToString();

            FPriceTb.Text = FAccessorieGv.CurrentRow.Cells[4].Value.ToString();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (QtyTb.Text == "" || FPriceTb.Text == "")
            {
                MessageBox.Show("Lütfen Tümünü Doldurun!");
            }
            else
            {
                try
                {
                    int rowIndex = BıllGv.CurrentCell.RowIndex;
                    BıllGv.Rows.RemoveAt(rowIndex);
                    Grdtotall = Grdtotall - total;
                    FtotalLbl.Text = Grdtotall + " TL";

                }
                catch
                {

                    MessageBox.Show("Ürün Bulunamadı!");
                }





            }
        }

        private void BıllGv_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            FProductTb.Text = BıllGv.CurrentRow.Cells[1].Value.ToString();
            FPriceTb.Text = BıllGv.CurrentRow.Cells[2].Value.ToString();
            QtyTb.Text = BıllGv.CurrentRow.Cells[3].Value.ToString();





        }
    }
}




