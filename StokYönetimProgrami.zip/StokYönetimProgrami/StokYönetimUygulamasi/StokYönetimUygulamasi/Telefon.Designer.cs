﻿namespace StokYönetimUygulamasi
{
    partial class Telefon
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Telefon));
            IdTb = new TextBox();
            label1 = new Label();
            label2 = new Label();
            ModeleTb = new TextBox();
            BrandTb = new TextBox();
            label4 = new Label();
            PriceTb = new TextBox();
            label5 = new Label();
            StockTb = new TextBox();
            label6 = new Label();
            RamCb = new ComboBox();
            MemoryCb = new ComboBox();
            label7 = new Label();
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();
            button4 = new Button();
            MobileGv = new DataGridView();
            label8 = new Label();
            button5 = new Button();
            ((System.ComponentModel.ISupportInitialize)MobileGv).BeginInit();
            SuspendLayout();
            // 
            // IdTb
            // 
            IdTb.Location = new Point(101, 61);
            IdTb.Name = "IdTb";
            IdTb.Size = new Size(167, 23);
            IdTb.TabIndex = 0;
            IdTb.TextChanged += IdTb_TextChanged;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Arial", 15.75F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(12, 61);
            label1.Name = "label1";
            label1.Size = new Size(41, 24);
            label1.TabIndex = 1;
            label1.Text = "Id :";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Arial", 15.75F, FontStyle.Bold, GraphicsUnit.Point);
            label2.Location = new Point(289, 62);
            label2.Name = "label2";
            label2.Size = new Size(83, 24);
            label2.TabIndex = 3;
            label2.Text = "Model :";
            // 
            // ModeleTb
            // 
            ModeleTb.Location = new Point(378, 57);
            ModeleTb.Name = "ModeleTb";
            ModeleTb.Size = new Size(167, 23);
            ModeleTb.TabIndex = 2;
            // 
            // BrandTb
            // 
            BrandTb.Location = new Point(101, 104);
            BrandTb.Name = "BrandTb";
            BrandTb.Size = new Size(167, 23);
            BrandTb.TabIndex = 4;
            BrandTb.TextChanged += textBox3_TextChanged;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Arial", 15.75F, FontStyle.Bold, GraphicsUnit.Point);
            label4.Location = new Point(301, 105);
            label4.Name = "label4";
            label4.Size = new Size(71, 24);
            label4.TabIndex = 7;
            label4.Text = "Fiyat :";
            // 
            // PriceTb
            // 
            PriceTb.Location = new Point(378, 104);
            PriceTb.Name = "PriceTb";
            PriceTb.Size = new Size(167, 23);
            PriceTb.TabIndex = 6;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Arial", 15.75F, FontStyle.Bold, GraphicsUnit.Point);
            label5.Location = new Point(877, 60);
            label5.Name = "label5";
            label5.Size = new Size(69, 24);
            label5.TabIndex = 9;
            label5.Text = "Stok :";
            // 
            // StockTb
            // 
            StockTb.Location = new Point(952, 61);
            StockTb.Name = "StockTb";
            StockTb.Size = new Size(167, 23);
            StockTb.TabIndex = 8;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Arial", 15.75F, FontStyle.Bold, GraphicsUnit.Point);
            label6.Location = new Point(578, 100);
            label6.Name = "label6";
            label6.Size = new Size(69, 24);
            label6.TabIndex = 11;
            label6.Text = "Ram :";
            // 
            // RamCb
            // 
            RamCb.FormattingEnabled = true;
            RamCb.Items.AddRange(new object[] { "1", "2", "3", "4", "6", "8", "12" });
            RamCb.Location = new Point(668, 104);
            RamCb.Name = "RamCb";
            RamCb.Size = new Size(167, 23);
            RamCb.TabIndex = 12;
            RamCb.SelectedIndexChanged += RamGb_SelectedIndexChanged;
            // 
            // MemoryCb
            // 
            MemoryCb.FormattingEnabled = true;
            MemoryCb.Items.AddRange(new object[] { "8", "16", "32", "64", "128", "256", "512" });
            MemoryCb.Location = new Point(668, 57);
            MemoryCb.Name = "MemoryCb";
            MemoryCb.Size = new Size(167, 23);
            MemoryCb.TabIndex = 14;
            MemoryCb.SelectedIndexChanged += comboBox2_SelectedIndexChanged;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Arial", 15.75F, FontStyle.Bold, GraphicsUnit.Point);
            label7.Location = new Point(578, 60);
            label7.Name = "label7";
            label7.Size = new Size(84, 24);
            label7.TabIndex = 13;
            label7.Text = "Hafıza :";
            // 
            // button1
            // 
            button1.AutoSize = true;
            button1.Font = new Font("Arial", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            button1.Location = new Point(13, 188);
            button1.Margin = new Padding(4, 3, 4, 3);
            button1.Name = "button1";
            button1.Size = new Size(195, 45);
            button1.TabIndex = 15;
            button1.Text = "Ekle";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.AutoSize = true;
            button2.Font = new Font("Arial", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            button2.Location = new Point(512, 188);
            button2.Margin = new Padding(4, 3, 4, 3);
            button2.Name = "button2";
            button2.Size = new Size(195, 45);
            button2.TabIndex = 16;
            button2.Text = "Güncelle";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // button3
            // 
            button3.AutoSize = true;
            button3.Font = new Font("Arial", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            button3.Location = new Point(254, 188);
            button3.Margin = new Padding(4, 3, 4, 3);
            button3.Name = "button3";
            button3.Size = new Size(195, 45);
            button3.TabIndex = 17;
            button3.Text = "Sil";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // button4
            // 
            button4.AutoSize = true;
            button4.Font = new Font("Arial", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            button4.Location = new Point(766, 188);
            button4.Margin = new Padding(4, 3, 4, 3);
            button4.Name = "button4";
            button4.Size = new Size(195, 45);
            button4.TabIndex = 18;
            button4.Text = "Temizle";
            button4.UseVisualStyleBackColor = true;
            button4.Click += button4_Click;
            // 
            // MobileGv
            // 
            MobileGv.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            MobileGv.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            MobileGv.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            MobileGv.Location = new Point(13, 279);
            MobileGv.Name = "MobileGv";
            MobileGv.ReadOnly = true;
            MobileGv.RowTemplate.Height = 25;
            MobileGv.Size = new Size(1304, 554);
            MobileGv.TabIndex = 19;
            MobileGv.CellContentClick += MobileGv_CellContentClick;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Arial", 15.75F, FontStyle.Bold, GraphicsUnit.Point);
            label8.Location = new Point(12, 105);
            label8.Name = "label8";
            label8.Size = new Size(90, 24);
            label8.TabIndex = 21;
            label8.Text = "Marka : ";
            // 
            // button5
            // 
            button5.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            button5.AutoSize = true;
            button5.Font = new Font("Arial", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            button5.Location = new Point(1228, 12);
            button5.Margin = new Padding(4, 3, 4, 3);
            button5.Name = "button5";
            button5.Size = new Size(88, 32);
            button5.TabIndex = 31;
            button5.Text = "Menü";
            button5.UseVisualStyleBackColor = true;
            button5.Click += button5_Click;
            // 
            // Telefon
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.DimGray;
            ClientSize = new Size(1329, 845);
            Controls.Add(button5);
            Controls.Add(label8);
            Controls.Add(MobileGv);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(MemoryCb);
            Controls.Add(label7);
            Controls.Add(RamCb);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(StockTb);
            Controls.Add(label4);
            Controls.Add(PriceTb);
            Controls.Add(BrandTb);
            Controls.Add(label2);
            Controls.Add(ModeleTb);
            Controls.Add(label1);
            Controls.Add(IdTb);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "Telefon";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Mobile";
            Load += Mobile_Load;
            ((System.ComponentModel.ISupportInitialize)MobileGv).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox IdTb;
        private Label label1;
        private Label label2;
        private TextBox ModeleTb;
        private TextBox BrandTb;
        private Label label4;
        private TextBox PriceTb;
        private Label label5;
        private TextBox StockTb;
        private Label label6;
        private ComboBox RamCb;
        private ComboBox MemoryCb;
        private Label label7;
        private Button button1;
        private Button button2;
        private Button button3;
        private Button button4;
        private DataGridView MobileGv;
        private Label label8;
        private Button button5;
    }
}