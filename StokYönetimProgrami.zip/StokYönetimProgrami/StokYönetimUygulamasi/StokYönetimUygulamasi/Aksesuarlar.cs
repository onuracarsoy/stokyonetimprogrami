﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace StokYönetimUygulamasi
{
    public partial class Aksesuarlar : Form
    {
        public Aksesuarlar()
        {
            InitializeComponent();
        }
        SqlConnection Con = new SqlConnection(@"Data Source=WINDEV2209EVAL;Initial Catalog=StokYonetim;Integrated Security=True");
        private void populate()
        {
            Con.Open();
            String query = "Select * from AccessorieTbl";
            SqlDataAdapter da = new SqlDataAdapter(query, Con);
            SqlCommandBuilder builder = new SqlCommandBuilder(da);
            var ds = new DataSet();
            da.Fill(ds);
            AccessoriesGv.DataSource = ds.Tables[0];
            Con.Close();
        }
        private void Aksesuarlar_Load(object sender, EventArgs e)
        {
            populate();
        }

        private void button2_Click(object sender, EventArgs e)

        {

            if (AIdTb.Text == "" || ABrandTb.Text == "" || AModelTb.Text == "" || APriceTb.Text == "" || AStockTb.Text == "")
            {
                MessageBox.Show("Lütfen Tümünü Doldurunuz!");
            }

            else

            {
                try
                {
                    Con.Open();
                    String sql = "update AccessorieTbl set AccessorieBrand='" + ABrandTb.Text + "', AccessorieModel='" + AModelTb.Text + "', AccessoriePrice='" + APriceTb.Text + "', AccessorieStock='" + AStockTb.Text + "' where AccessorieId=" + AIdTb.Text + ";";
                    SqlCommand cmd = new SqlCommand(sql, Con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Başarı ile güncellendi!");
                    Con.Close();
                    populate();

                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }

            }
        }

        private void IdTb_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (AIdTb.Text == "" || ABrandTb.Text == "" || AModelTb.Text == "" || APriceTb.Text == "" || AStockTb.Text == "")
            {
                MessageBox.Show("Lütfen Tümünü Doldurunuz!");
            }
            else
            {
                try
                {
                    Con.Open();
                    String sql = "insert into AccessorieTbl values(" + AIdTb.Text + ",'" + ABrandTb.Text + "','" + AModelTb.Text + "','" + AStockTb.Text + "','" + APriceTb.Text + "')";
                    SqlCommand cmd = new SqlCommand(sql, Con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Başarı ile eklendi!");
                    Con.Close();
                    populate();

                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }

            }
        }

        private void button3_Click(object sender, EventArgs e)
        {


            if (AIdTb.Text == "")
            {
                MessageBox.Show("Lütfen Id Bilgisi Giriniz!");
            }

            else
            {
                try
                {
                    Con.Open();
                    string query = "delete from AccessorieTbl where AccessorieId=" + AIdTb.Text + "";
                    SqlCommand cmd = new SqlCommand(query, Con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Başarı ile silindi!");
                    Con.Close();
                    populate();

                }
                catch (Exception Ex)
                {

                }
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            AIdTb.Text = "";
            ABrandTb.Text = "";
            AModelTb.Text = "";
            APriceTb.Text = "";
            AStockTb.Text = "";
        }

        private void AccessoriesGv_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            AIdTb.Text = AccessoriesGv.CurrentRow.Cells[0].Value.ToString();
            ABrandTb.Text = AccessoriesGv.CurrentRow.Cells[1].Value.ToString();
            AModelTb.Text = AccessoriesGv.CurrentRow.Cells[2].Value.ToString();
            APriceTb.Text = AccessoriesGv.CurrentRow.Cells[4].Value.ToString();
            AStockTb.Text = AccessoriesGv.CurrentRow.Cells[3].Value.ToString();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Menu mn = new Menu();
            mn.Show();
            this.Hide();
        }
    }
}
