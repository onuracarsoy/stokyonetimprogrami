﻿namespace StokYönetimUygulamasi
{
    partial class Aksesuarlar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Aksesuarlar));
            label5 = new Label();
            AStockTb = new TextBox();
            label4 = new Label();
            APriceTb = new TextBox();
            label3 = new Label();
            ABrandTb = new TextBox();
            label2 = new Label();
            AModelTb = new TextBox();
            label1 = new Label();
            AIdTb = new TextBox();
            button4 = new Button();
            button3 = new Button();
            button2 = new Button();
            button1 = new Button();
            AccessoriesGv = new DataGridView();
            button5 = new Button();
            ((System.ComponentModel.ISupportInitialize)AccessoriesGv).BeginInit();
            SuspendLayout();
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Arial", 15.75F, FontStyle.Bold, GraphicsUnit.Point);
            label5.Location = new Point(1038, 62);
            label5.Name = "label5";
            label5.Size = new Size(69, 24);
            label5.TabIndex = 24;
            label5.Text = "Stok :";
            // 
            // AStockTb
            // 
            AStockTb.Location = new Point(1113, 61);
            AStockTb.Name = "AStockTb";
            AStockTb.Size = new Size(167, 23);
            AStockTb.TabIndex = 23;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Arial", 15.75F, FontStyle.Bold, GraphicsUnit.Point);
            label4.Location = new Point(781, 63);
            label4.Name = "label4";
            label4.Size = new Size(71, 24);
            label4.TabIndex = 22;
            label4.Text = "Fiyat :";
            // 
            // APriceTb
            // 
            APriceTb.Location = new Point(858, 63);
            APriceTb.Name = "APriceTb";
            APriceTb.Size = new Size(167, 23);
            APriceTb.TabIndex = 21;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Arial", 15.75F, FontStyle.Bold, GraphicsUnit.Point);
            label3.Location = new Point(230, 62);
            label3.Name = "label3";
            label3.Size = new Size(84, 24);
            label3.TabIndex = 20;
            label3.Text = "Marka :";
            // 
            // ABrandTb
            // 
            ABrandTb.Location = new Point(320, 62);
            ABrandTb.Name = "ABrandTb";
            ABrandTb.Size = new Size(167, 23);
            ABrandTb.TabIndex = 19;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Arial", 15.75F, FontStyle.Bold, GraphicsUnit.Point);
            label2.Location = new Point(505, 63);
            label2.Name = "label2";
            label2.Size = new Size(83, 24);
            label2.TabIndex = 18;
            label2.Text = "Model :";
            // 
            // AModelTb
            // 
            AModelTb.Location = new Point(594, 64);
            AModelTb.Name = "AModelTb";
            AModelTb.Size = new Size(167, 23);
            AModelTb.TabIndex = 17;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Arial", 15.75F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(11, 61);
            label1.Name = "label1";
            label1.Size = new Size(41, 24);
            label1.TabIndex = 16;
            label1.Text = "Id :";
            // 
            // AIdTb
            // 
            AIdTb.Location = new Point(55, 63);
            AIdTb.Name = "AIdTb";
            AIdTb.Size = new Size(167, 23);
            AIdTb.TabIndex = 15;
            AIdTb.TextChanged += IdTb_TextChanged;
            // 
            // button4
            // 
            button4.AutoSize = true;
            button4.Font = new Font("Arial", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            button4.Location = new Point(728, 127);
            button4.Margin = new Padding(4, 3, 4, 3);
            button4.Name = "button4";
            button4.Size = new Size(195, 45);
            button4.TabIndex = 28;
            button4.Text = "Temizle";
            button4.UseVisualStyleBackColor = true;
            button4.Click += button4_Click;
            // 
            // button3
            // 
            button3.AutoSize = true;
            button3.Font = new Font("Arial", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            button3.Location = new Point(246, 127);
            button3.Margin = new Padding(4, 3, 4, 3);
            button3.Name = "button3";
            button3.Size = new Size(195, 45);
            button3.TabIndex = 27;
            button3.Text = "Sil";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // button2
            // 
            button2.AutoSize = true;
            button2.Font = new Font("Arial", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            button2.Location = new Point(490, 127);
            button2.Margin = new Padding(4, 3, 4, 3);
            button2.Name = "button2";
            button2.Size = new Size(195, 45);
            button2.TabIndex = 26;
            button2.Text = "Güncelle";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // button1
            // 
            button1.AutoSize = true;
            button1.Font = new Font("Arial", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            button1.Location = new Point(14, 127);
            button1.Margin = new Padding(4, 3, 4, 3);
            button1.Name = "button1";
            button1.Size = new Size(195, 45);
            button1.TabIndex = 25;
            button1.Text = "Ekle";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // AccessoriesGv
            // 
            AccessoriesGv.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            AccessoriesGv.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            AccessoriesGv.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            AccessoriesGv.Location = new Point(12, 208);
            AccessoriesGv.Name = "AccessoriesGv";
            AccessoriesGv.ReadOnly = true;
            AccessoriesGv.RowTemplate.Height = 25;
            AccessoriesGv.Size = new Size(1304, 613);
            AccessoriesGv.TabIndex = 29;
            AccessoriesGv.CellContentClick += AccessoriesGv_CellContentClick;
            // 
            // button5
            // 
            button5.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            button5.AutoSize = true;
            button5.Font = new Font("Arial", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            button5.Location = new Point(1228, 12);
            button5.Margin = new Padding(4, 3, 4, 3);
            button5.Name = "button5";
            button5.Size = new Size(88, 32);
            button5.TabIndex = 30;
            button5.Text = "Menü";
            button5.UseVisualStyleBackColor = true;
            button5.Click += button5_Click;
            // 
            // Aksesuarlar
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.DimGray;
            ClientSize = new Size(1329, 845);
            Controls.Add(button5);
            Controls.Add(AccessoriesGv);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(label5);
            Controls.Add(AStockTb);
            Controls.Add(label4);
            Controls.Add(APriceTb);
            Controls.Add(label3);
            Controls.Add(ABrandTb);
            Controls.Add(label2);
            Controls.Add(AModelTb);
            Controls.Add(label1);
            Controls.Add(AIdTb);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "Aksesuarlar";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Aksesuar";
            Load += Aksesuarlar_Load;
            ((System.ComponentModel.ISupportInitialize)AccessoriesGv).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Label label5;
        private TextBox AStockTb;
        private Label label4;
        private TextBox APriceTb;
        private Label label3;
        private TextBox ABrandTb;
        private Label label2;
        private TextBox AModelTb;
        private Label label1;
        private TextBox AIdTb;
        private Button button4;
        private Button button3;
        private Button button2;
        private Button button1;
        private DataGridView AccessoriesGv;
        private Button button5;
    }
}