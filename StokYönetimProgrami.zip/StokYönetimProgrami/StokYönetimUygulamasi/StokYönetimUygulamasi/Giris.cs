﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StokYönetimUygulamasi
{
    public partial class Giris : Form
    {
        public Giris()
        {
            InitializeComponent();
        }
        SqlConnection Con = new SqlConnection(@"Data Source=WINDEV2209EVAL;Initial Catalog=StokYonetim;Integrated Security=True");

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Con.Open();
            SqlDataAdapter sda = new SqlDataAdapter("select Count(*) from UserTbl where UserName ='" + UserNameTb.Text + "' and UserPassword='" + PasswordTb.Text + "'", Con);
            DataTable dt = new DataTable();
            sda.Fill(dt);

            if (dt.Rows[0][0].ToString() == "1")
            {

                Menu mn = new Menu();
                mn.Show();
                this.Hide();


            }
            else if (UserNameTb.Text == "" || PasswordTb.Text == "")
            {
                MessageBox.Show("Lütfen Kullanıcı Adı Ya Da Şifre Giriniz!");
            }
            else
            {
                MessageBox.Show("Kullanıcı Adı Ya Da Şifre Yanlış!");
            }
            Con.Close();

        }

        private void Login_Load(object sender, EventArgs e)
        {

        }
    }
}

