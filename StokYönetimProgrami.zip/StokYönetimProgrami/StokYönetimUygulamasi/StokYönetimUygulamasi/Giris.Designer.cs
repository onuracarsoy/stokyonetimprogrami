﻿namespace StokYönetimUygulamasi
{
    partial class Giris
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Giris));
            UserNameTb = new TextBox();
            PasswordTb = new TextBox();
            button1 = new Button();
            label1 = new Label();
            label2 = new Label();
            pictureBox1 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // UserNameTb
            // 
            UserNameTb.Font = new Font("Arial", 11.25F, FontStyle.Regular, GraphicsUnit.Point);
            UserNameTb.Location = new Point(295, 245);
            UserNameTb.Margin = new Padding(4, 3, 4, 3);
            UserNameTb.Name = "UserNameTb";
            UserNameTb.Size = new Size(347, 25);
            UserNameTb.TabIndex = 0;
            UserNameTb.TextChanged += textBox1_TextChanged;
            // 
            // PasswordTb
            // 
            PasswordTb.Font = new Font("Arial", 11.25F, FontStyle.Regular, GraphicsUnit.Point);
            PasswordTb.Location = new Point(295, 300);
            PasswordTb.Margin = new Padding(4, 3, 4, 3);
            PasswordTb.Name = "PasswordTb";
            PasswordTb.Size = new Size(347, 25);
            PasswordTb.TabIndex = 1;
            PasswordTb.UseSystemPasswordChar = true;
            // 
            // button1
            // 
            button1.AutoSize = true;
            button1.Font = new Font("Arial", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            button1.Location = new Point(365, 348);
            button1.Margin = new Padding(4, 3, 4, 3);
            button1.Name = "button1";
            button1.Size = new Size(195, 45);
            button1.TabIndex = 2;
            button1.Text = "Giriş Yap";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label1.Location = new Point(190, 247);
            label1.Name = "label1";
            label1.Size = new Size(98, 18);
            label1.TabIndex = 4;
            label1.Text = "Kullanıcı Adı :";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label2.Location = new Point(235, 300);
            label2.Name = "label2";
            label2.Size = new Size(53, 18);
            label2.TabIndex = 5;
            label2.Text = "Şifre : ";
            label2.Click += label2_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.BackgroundImage = (Image)resources.GetObject("pictureBox1.BackgroundImage");
            pictureBox1.Location = new Point(350, 12);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(221, 215);
            pictureBox1.TabIndex = 6;
            pictureBox1.TabStop = false;
            // 
            // Giris
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            AutoSize = true;
            BackColor = Color.DimGray;
            ClientSize = new Size(924, 435);
            Controls.Add(pictureBox1);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(button1);
            Controls.Add(PasswordTb);
            Controls.Add(UserNameTb);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Margin = new Padding(4, 3, 4, 3);
            Name = "Giris";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Giris";
            Load += Login_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox UserNameTb;
        private TextBox PasswordTb;
        private Button button1;
        private Label label1;
        private Label label2;
        private PictureBox pictureBox1;
    }
}